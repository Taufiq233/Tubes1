<!DOCTYPE html>
<html>
<head>
	<title>login</title>
	<link rel="stylesheet" type="text/css" href="style1.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
</head>
<body>
	<div class="kotak_login">
        <img src="Vector.png" alt="vector">
        <h3 class="tulisan_login">Sign up for Tonality</h3>
 
			<div class="input-field">
                <label for="regUser">Username</label><br>
                <input type="text" class="input-box" id="regUser" required>
            </div>
			<div class="input-field">
				<label>Password</label><br>
				<input type="password" name="password" id="password" >
				<!-- <div class="eye-area">
                        <div class="eye-box" onclick="myRegPassword()">
							<i class="fa-solid fa-eye" id="eye"></i>
                        </div>
                 </div> -->
			</div>
            <center><input type="submit" class="tombol_login" value="Sign Up"></center>
			<br/>
			<br/>
			<center>
				<label>Already have an account? <a href="login1.php" class="link"> Log in to Tonality</a></label>
			</center>

		
	</div>
 
<!-- <script>
	const passwordInput = document.querySelector("#password")
	const eye = document.querySelector("#eye")
	eye.addEventListener("click", function(){
		this.classList.toggle("fa-eye-slash")
		const type = passwordInput.getAttribute("type") === "password" ? "text" : "password"
		passwordInput.setAttribute("type", type)
	})
</script> -->
</body>
</html>